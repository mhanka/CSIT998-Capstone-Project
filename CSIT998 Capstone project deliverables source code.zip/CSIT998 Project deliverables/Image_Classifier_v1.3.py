from numpy import random
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import os
import torch, torchvision
from torch import device
from torchvision import datasets, models, transforms
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader
import time
from torchsummary import summary


# Transforming Images so that model get to train on more variation of same data
image_transforms = {
    'valid': transforms.Compose([
        transforms.Resize(size=256),
        transforms.CenterCrop(size=224),
        transforms.ToTensor(),
        transforms.Normalize([0.485, 0.456, 0.406],
                             [0.229, 0.224, 0.225])
    ]),
    'train': transforms.Compose([
        transforms.RandomResizedCrop(size=256, scale=(0.8, 1.0)),
        transforms.RandomRotation(degrees=15),
        transforms.RandomHorizontalFlip(),
        transforms.CenterCrop(size=224),
        transforms.ToTensor(),
        transforms.Normalize([0.485, 0.456, 0.406],
                             [0.229, 0.224, 0.225])
    ])

}

dataset = "C:\\Users\\kaila\\PycharmProjects\\ImageClassification\\images"

train_directory = os.path.join(dataset, 'train')
valid_directory = os.path.join(dataset, 'valid')
print(train_directory)
# Batch size
batchSize = 32

artistsNameList = pd.read_csv('C:\\Users\\kaila\\PycharmProjects\\ImageClassification\\artists.csv')
print("Artist Shape", artistsNameList.shape)
artist_dirs = os.listdir(train_directory)
artistsNameList['dir'] = artistsNameList['name'].str.split(' ').str.join('_')
for name in artistsNameList['dir']:
    if name not in artist_dirs:
        print('Cannot find ', name)

artistsNameList.sort_values(by='paintings', inplace=True, ascending=False)
top_artists = artistsNameList[artistsNameList['paintings'] > 1]
print("Top Artist", top_artists.loc[:, ['name', 'paintings']])

top_artists = artistsNameList[artistsNameList['paintings'] > 1]
top_artists['class_weight'] = top_artists.paintings.sum() / (top_artists.shape[0] * top_artists.paintings)

print("Top Artist By Class Weight", top_artists.loc[:, ['name', 'paintings', 'class_weight']])
print('Total number of paintings: ', top_artists['paintings'].sum())

class_weights = top_artists['class_weight'].to_dict()

print("Class Weight", class_weights)

fig_size = (2, 4)
fig, axes = plt.subplots(fig_size[0], fig_size[1], figsize=(20, 15))
for row in axes:
    for axe in row:
        random_name = random.choice(top_artists['dir'].to_list())
        random_image = random.choice(os.listdir(os.path.join(train_directory, random_name)))
        random_image_file = os.path.join(train_directory, random_name, random_image)
        random_image_file = plt.imread(random_image_file)
        axe.imshow(random_image_file)
        axe.set_title(random_name)

num_classes = len(os.listdir(train_directory))
print("Total number of trainable classes", num_classes)


data = {
    'train': datasets.ImageFolder(root=train_directory, transform=image_transforms['train']),
    'valid': datasets.ImageFolder(root=valid_directory, transform=image_transforms['valid'])
}

# helps the model to compare the predicted value to the map generated from here
#artistMap = {v: k for k, v in data['train'].class_to_idx.items()}
#print("Map of artists", artistMap)

# Size of train and valid datasets to calculate loss and accuracy
train_data_size = len(data['train'])
valid_data_size = len(data['valid'])

# iterators for the Data loaded using DataLoader module
train_data_loader = DataLoader(data['train'], batch_size=batchSize, shuffle=True)
valid_data_loader = DataLoader(data['valid'], batch_size=batchSize, shuffle=True)

train_data_size, valid_data_size
#import the pretrained ALEX NET model
alexnet = models.alexnet(pretrained=True)


for param in alexnet.parameters():
    param.requires_grad = False

alexnet.classifier[6] = nn.Linear(4096, num_classes)
alexnet.classifier.add_module("23", nn.LogSoftmax(dim=1))

# shows the layers of the alexnet model and trainable parameters
summary(alexnet, (3, 224, 224))


# selecting loss function
nllLoss = nn.NLLLoss()
# Adam optimizer for gradient descent
optimizer = optim.Adam(alexnet.parameters())


# train and validate function
def trainValidate(model, nLLloss, Adam_Optimizer, epochs):
    history = []
    start = time.time()

    for epoch in range(epochs):
        epoch_start = time.time()
        print("Epoch: {}/{}".format(epoch + 1, epochs))

        # Set model to training mode
        model.train()

        # defined to calculate loss and acc within an epoch
        train_loss = 0.0
        train_acc = 0.0
        # for validation
        valid_loss = 0.0
        valid_acc = 0.0

        # train loop
        for k, (inputs, labels) in enumerate(train_data_loader):
            inputs = inputs.to(device)
            labels = labels.to(device)
            # set to zero gradient to avoid wrong learning
            Adam_Optimizer.zero_grad()
            # Forward pass - compute outputs on input data using the model
            outputs = model(inputs)
            # loss calculation
            loss = nLLloss(outputs, labels)
            # Backpropagation of the gradient to relearn and adjust neurons
            loss.backward()
            # Update the parameters
            Adam_Optimizer.step()
            # Compute the total loss for the batch and add it to train_loss
            train_loss += loss.item() * inputs.size(0)
            # Compute the accuracy
            ret, predictions = torch.max(outputs.data, 1)
            correct_pred_count = predictions.eq(labels.data.view_as(predictions))
            # Convert correct_pred_count to float and then compute the mean
            acc = torch.mean(correct_pred_count.type(torch.FloatTensor))

            # Compute total accuracy in the whole batch and add to training_accuracy
            train_acc += acc.item() * inputs.size(0)

            # print("Batch number: {:03d}, Training: Loss: {:.4f}, Accuracy: {:.4f}".format(i, loss.item(), acc.item()))

        # Validation - No gradient tracking needed
        with torch.no_grad():

            # model in evaluation phase
            model.eval()

            for m, (inputs, labels) in enumerate(valid_data_loader):
                inputs = inputs.to(device)
                labels = labels.to(device)
                # Forward pass - compute outputs on input data using the alexnet
                outputs = model(inputs)
                # calculate loss
                loss = nLLloss(outputs, labels)
                print("Loss Probability", loss)
                # Compute the total loss for the batch and add it to valid_loss
                valid_loss += loss.item() * inputs.size(0)
                #no need for back propagation in evaluation mode
                # Calculate validation accuracy by comapring the label with predicted class
                ret, predictions = torch.max(outputs.data, 1)
                correct_pred_count = predictions.eq(labels.data.view_as(predictions))
                # Convert correct_pred_count to float and then compute the mean
                acc = torch.mean(correct_pred_count.type(torch.FloatTensor))

                # Compute total accuracy in the whole batch and add to valid_acc
                valid_acc += acc.item() * inputs.size(0)

        # Find average training loss and training accuracy
        avg_train_loss = train_loss / train_data_size
        avg_train_acc = train_acc / train_data_size

        # Find average training loss and training accuracy
        avg_valid_loss = valid_loss / valid_data_size
        avg_valid_acc = valid_acc / valid_data_size

        history.append([avg_train_loss, avg_valid_loss, avg_train_acc, avg_valid_acc])

        epoch_end = time.time()

        print("Epoch : {:03d}, Training: Loss: {:.4f}, Accuracy: {:.4f}%, \n\t\tValidation : Loss : {:.4f}, Accuracy: {:.4f}%, Time: {:.4f}s".format(
                epoch + 1, avg_train_loss, avg_valid_loss, avg_train_acc * 100, avg_valid_acc * 100,
                epoch_end - epoch_start))

        # save the best model => over repetitive training i saw that the model at last is having maximum accuracy
        if epoch == 99:
            torch.save(model, 'ArtistModel'+str(epoch)+'.pth')

    return model, history


# code select between GPU and CPU
device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")

num_epochs = 50
trained_model, history = trainValidate(alexnet, nllLoss, optimizer, num_epochs)

torch.save(history, dataset + '_history.pth')


# plot loss graph
history = np.array(history)
plt.plot(history[:, 0:5])
plt.legend(['Training Loss', 'Validation Loss'])
plt.ylabel('Loss')
plt.xlabel('Number of Epoch ')
plt.ylim(0, 1)
plt.savefig(dataset + '_loss_graph.png')

# plot accuracy graph
plt.plot(history[:, 2:5])
plt.legend(['Training Accuracy', 'Validation Accuracy'])
plt.ylabel('Accuracy')
plt.xlabel('Number of Epoch ')
plt.ylim(0, 1)
plt.savefig(dataset + '_accuracy_graph.png')


#END
