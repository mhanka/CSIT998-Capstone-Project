# Artist classification and Price prediction model for Art auctions 

### @Authors
*Mohan Krishna Kuppan (Leader) 6573150*

*Kailaash Kanna Kannaiah 6866578* 

*Vinodh Kumar Rajasekaran 6860539* 

-------------------------------------------------------


## Web Scrapping

- Array initialization
- Setup chromedriver
    - Driver path
- Run in server mode
- URL request
- Extract internal URL links
- Second URL request
    - Parse DOM
    - Extract data form secondary URL response
- Store as dataframe
- Write in excel

**Procedure :**

 1] Install chrome driver (according the version of your browser) and provide local file path.

 2] Specify the path where the data scrapped to be saved.

 3] Run the program

 4] File will be saved once the excuetion is finished.

Source Code [Link](https://uowmailedu-my.sharepoint.com/:u:/g/personal/kkk559_uowmail_edu_au/EfmoInVSkqNErNsvND13zecBYYSuifKV3C3I_ExC70RAtw?e=9aTjCx)

-------------------------------------------------------

## URL to Image

- Read CSV
- Extract URL 
- Retrive URL image by a https request
- Save the image downloaded into folder

**Procedure :**
1] Specify the path of the URL files.

2] Choose the download directory for the images to be saved.

3] Run the program.

Source Code [Link](https://uowmailedu-my.sharepoint.com/:u:/g/personal/kkk559_uowmail_edu_au/ETefN08bd0pIpXhjgINTvO4BBW5mMqO6vM6kDol3Qo29qw?e=a3dUNz)

-------------------------------------------------------

## Image classification code 

- Import images (OS path)
- Image Transform
- Class Weight calculation
- load train & validate data
- Alext Import 
- Funtion of train and validate
    - Train section
    - Model output
    - Model accuracy, loss
    - Gradient
    - Back propogate
- Validate section
    - Accuracy and loss
    - Back propagation
    - Gradient desect apply
    - Calculate epoch time, accuracy, losses
    - History save
    - Save best model
    - Plot graph


**Procedure :**
1] Mount the image directories to program. You can find the images in [here](https://uowmailedu-my.sharepoint.com/:f:/g/personal/kkk559_uowmail_edu_au/Epr0I28YIj1HoZls_Y0VaIUBZCL9TmvIk0j4wOcHS7uUkw?e=hcObqM) for download.

2] Import all the necessay plugins and the pre-trained alex net model.

3] Specify the number of epochs to be trained.

4] Run the program.

5] Configure parameter as needed to save the best model in the mounted directory.

6] Graphs will be plotted and saved in the same directory.

Source Code [Link](https://uowmailedu-my.sharepoint.com/:u:/g/personal/kkk559_uowmail_edu_au/EVWnxhIQGwJEl5qaYif8o54BqT9B32Dbo7_l-dpMVUrc4g?e=MDyR86)

-------------------------------------------------------

## WebApp Code 

- Import the saved model
- Get the image form UI
    - Tranform image
    - Pass image to model
    - Compare the predicted result using artist map
- Display the calculated accurarcy and predicted artist in the UI

**Procedure :**
1] Specify the location of the trained model named as "Artist_Prediction_Model_V1.7" downloaded from [here](https://uowmailedu-my.sharepoint.com/:u:/g/personal/kkk559_uowmail_edu_au/EVeXkPKvXn1Bs98J3j35TFkBe7pJOvu7nsRS5VyKswAtVQ?e=CReceG).

2] Mount the location of the model to the program.

3] Run the program.

4] Enter commmand ```streamlit run webApp.py ``` in the intergrated terminal to start the web application.

5] A new browser window will be opened at http://localhost:8501

6] Try our prediction model.

Source Code [Link](https://uowmailedu-my.sharepoint.com/:u:/g/personal/kkk559_uowmail_edu_au/EY9dhGZLNlhCk_9vJ5djouABO65aPTICA86jWSJa9AmTCw?e=StbyVP)

-------------------------------------------------------

## Linear Regression

- Read CSV file
- Convert to dataframe
- Remove NULL values 
- Test / train spilt
- Perform batch scalariazation
- Perform liner regression
- Model evaluation using statistical estimators
- Visualize prediction 
- Visualize normalization

**Procedure :**
1] Mount CSV file to local path.

2] Provide file path to save the plots.

3] Run the program.

Source Code [Link](https://uowmailedu-my.sharepoint.com/:u:/g/personal/kkk559_uowmail_edu_au/Eanv2FDpbGtFiG7wiPg83OIBHk7WxnR98EoHuRHclVg2Wg?e=n9miH1)

-------------------------------------------------------