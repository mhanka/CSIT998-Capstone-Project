import torch
from PIL import Image
from torchvision import transforms
import streamlit as st
import numpy as np


Artist_Map = {0: 'Albrecht_Dürer', 1: 'Alfred_Sisley', 2: 'Amedeo_Modigliani', 3: 'Andy_Warhol', 4: 'Camille_Pissarro',
                5: 'Claude_Monet', 6: 'Edgar_Degas', 7: 'Francisco_Goya', 8: 'Frida_Kahlo',
                9: 'Hieronymus_Bosch', 10: 'Jackson_Pollock', 11: 'Joan_Miro', 12: 'Leonardo',
                13: 'Michelangelo', 14: 'Mikhail_Vrubel', 15: 'Pablo_Picasso', 16: 'Paul_Gauguin',
                17: 'Paul_Klee', 18: 'Rene_Magritte', 19: 'Vasiliy_Kandinskiy',
                20: 'Vincent_van_Gogh', 21: 'William_Turner'}

# trained model taken from the main file
trained_model = torch.load('ArtistPredictionModel_V1.7.pth')
st.write("""# Artist Prediction Model""")
st.write("This is a painting classification web app to predict the artist")
#Type of image formats
file = st.file_uploader("Please upload an image file", type=["jpg", "png", "jpeg"])

image_transforms = transforms.Compose([
        transforms.Resize(size=256),
        transforms.CenterCrop(size=224),
        transforms.ToTensor(),
        transforms.Normalize([0.485, 0.456, 0.406],
                             [0.229, 0.224, 0.225])
    ])


def import_and_predict(image, model):
    # display image in the page
    st.image(image)
# conversion to tensor from image
    with torch.no_grad():
        model.eval()
        test_image_tensor = image_transforms(image)
        test_image_tensor = test_image_tensor.view(1, 3, 224, 224)
        out = model(test_image_tensor)
        ps = torch.exp(out)
        weightedClassKey, weightedClass = ps.topk(1, dim=1)
        for i in range(1):
            st.write("Prediction", i + 1, ":", Artist_Map[weightedClass.numpy()[0][i]], ", Prediction Score: ", weightedClassKey.numpy()[0][i]*100,"%")


if file is None:
    st.text("Please upload only an image file")
else:
    user_image = Image.open(file)
    import_and_predict(user_image, trained_model)




