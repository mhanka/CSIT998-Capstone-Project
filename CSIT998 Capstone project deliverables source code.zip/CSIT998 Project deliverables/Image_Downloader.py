import pandas as pd
import urllib.request


# url retrieve downloads the image using Https link

def url_to_jpg(i, artist, url, file_path):
    filename = '{}-{}.jpg'.format(artist, i)
    full_path = '{}{}'.format(file_path, filename)
    urllib.request.urlretrieve(url, full_path)

    print('{} saved.'.format(filename))

    return None


# CSV file with link and artist name is taken here
FILENAME = 'link.csv'
file_path = 'C:\\images\\train'
# Read each line from csv file
urls = pd.read_csv(FILENAME, encoding='latin1')

# function call
for i, url in enumerate(urls.values):
    url_to_jpg(i, url[0], url[1], file_path)
